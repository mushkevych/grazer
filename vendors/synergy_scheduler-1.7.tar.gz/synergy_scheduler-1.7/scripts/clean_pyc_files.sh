#!/bin/bash

find .. -type f -name "*.pyc" -delete;