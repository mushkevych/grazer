__author__ = 'Bohdan Mushkevych'

TRIGGER_INTERVAL = 5    # seconds between checking process state

PROCESS_SUPERVISOR = 'Supervisor'
TOKEN_SUPERVISOR = 'supervisor'

COLLECTION_BOX_CONFIGURATION = 'box_configuration'
