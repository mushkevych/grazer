if __name__ == '__main__':
    from IPython.parallel.apps import ipclusterapp as app
    app.launch_new_instance()
