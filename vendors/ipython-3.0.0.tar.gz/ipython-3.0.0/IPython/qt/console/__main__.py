if __name__ == '__main__':
    from IPython.qt.console.qtconsoleapp import main
    main()
