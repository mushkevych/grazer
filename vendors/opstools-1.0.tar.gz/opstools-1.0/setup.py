from distutils.core import setup

setup(
    name='opstools',
    version='1.0',
    description="Systems provisioning and orchestration tools",
    packages=['helpers', 'opstools'],
    author='Nadir Merchant',
    author_email='nadir.merchant@mobidia.com',
    install_requires=['boto', 'fabric']
)
