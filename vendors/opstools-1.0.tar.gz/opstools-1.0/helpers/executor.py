#!/usr/bin/python

# Execute puppet agent deploy script to configure initial state and start puppet agent
# Private key pem file must be present in ssh config of the user account executing this script. ~/.ssh/config
# Example: (/tmp)$./agent_deploy.sh bw-agent.mobidia.com production 10.1.234.2


import time

from fabric.api import *
from fabric.exceptions import NetworkError


def bootstrap(name, environment, ip, addr):
    print "Attempting to bootstrap: %s %s %s %s" % (name, environment, ip, addr)

    # Setup SSH connection
    env.use_ssh_config = True
    env.user = 'root'
    env.host_string = ip
    env.warn_only = True

    # Try to ssh into box for 3 minutes before failing
    while True:
        count = [0]
        try:
            with cd('/tmp'):
                run("./agent_deploy.sh %s %s %s" % (name, environment, addr))
                run("service puppet start")  # TODO: Enable after testing is complete
                print 'Successfully bootstrapped instance'
                break
        except NetworkError:
            if count[0] > 30:
                print 'Giving up after attempting to connect to %s for 3 minutes' % ip
                break
            print 'Instance not ready, retrying in 10 seconds...'
            time.sleep(10)
            count[0] += 1


def agent_kick(hostnames):

    #env.use_ssh_config = True
    env.user = 'root'
    env.warn_only = True
    env.key_filename = '/root/.ssh/bluewhale.pem'
    #env.hosts = hostnames

    for host in hostnames:
        with settings(host_string=host):
            run("puppet agent -t &", pty=False)  #TODO: Look for a better way to trigger a run than backgrounding puppet agent -t


def run_arbitrary(hostnames, command):

    env.user = 'root'
    env.warn_only = True
    env.key_filename = '/root/.ssh/bluewhale.pem'

    for host in hostnames:
        with settings(host_string=host):
            run(command, pty=False)
            print ('\n')