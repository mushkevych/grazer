#!/usr/bin/python
__author__ = 'Nadir Merchant'

import sys
from getopt import getopt, GetoptError

from boto.s3.bucket import Bucket
from boto.s3 import connect_to_region

from settings import settings


def main(*argv):

    _file = None
    bucket_name = None
    expiration_minutes = 60*75  # 75 minutes

    try:
        opts, args = getopt(argv[0], "t:b:f:")
    except GetoptError:
        sys.exit(2)

    for opt, arg in opts:
        if opt == '-b':
            bucket_name = arg
        if opt == '-t':
            expiration_minutes = arg
        if opt == '-f':
            _file = arg

    if not bucket_name and not _file:
        print '-b Bucket Name and -f file (S3 file key) are required'
        sys.exit(3)

    conn = connect_to_region(settings['REGION'],
                             aws_access_key_id=settings['AWS_KEY_ID'],
                             aws_secret_access_key=settings['AWS_SECRET_KEY'])
    bucket = Bucket(conn, bucket_name)
    key = bucket.get_key(_file)
    url = key.generate_url(expires_in=expiration_minutes)

    print "'%s'" % url
    return url

if __name__ == "__main__":
    main(sys.argv[1:])
