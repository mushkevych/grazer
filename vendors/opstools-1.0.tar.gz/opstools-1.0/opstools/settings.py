settings = dict(
    AWS_KEY_ID='AKIAJNK2P6DRSVAJI5UQ',
    AWS_SECRET_KEY='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',
    REGION='us-east-1',

    # AWS Provision Default values
    base_security_group=['bluewhale'],
    instance_size='m1.small',
    num_of_instances=1,
    default_ami='ami-c033b3a8',
    expiration_delta=2,
    bid_factor=1.2,

    m3_xlarge_price=0.28,
    m3_large_price=0.14,
    m3_medium_price=0.07,
    m1_small_price=0.044
)