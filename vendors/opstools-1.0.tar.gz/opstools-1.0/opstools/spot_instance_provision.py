from time import sleep
import sys
from datetime import datetime, timedelta

from boto.ec2 import connect_to_region

from settings import settings
from helpers.executor import bootstrap
from aws_provision import validate_instance_size, provision


# TODO: Add logic to cancel run if instances are not provisioned within x time


def main(*argv):
    key = settings['AWS_KEY_ID']
    secret_key = settings['AWS_SECRET_KEY']
    region = settings['REGION']
    environment = 'production'
    name = 'worker-test'

    # Connect to AWS
    print 'Connecting to AWS'

    conn = connect_to_region(region,
                             aws_access_key_id=key,
                             aws_secret_access_key=secret_key)

    spot_provision(conn,
                   settings['ami'],
                   settings['instance_size'],
                   settings['security_groups'],
                   settings['num_of_instances'],
                   environment,
                   name)


def spot_provision(conn, ami, instance_size, security_groups, num_of_instances, environment, name):

    validate_instance_size(instance_size)

    # Set market price for on-demand instances
    if instance_size == 'm3.xlarge':
        base_price = settings['m3_xlarge_price']
    elif instance_size == 'm3.large':
        base_price = settings['m3_large_price']
    elif instance_size == 'm3.medium':
        base_price = settings['m3_medium_price']
    else:
        base_price = settings['m1_small_price']

    # Returns a list of objects where object.price is a float representing the current price for each AZ in region
    price_history = conn.get_spot_price_history(instance_type=instance_size,
                                                max_results=5)
    # Get the lowest current bid price
    bid = base_price
    for record in price_history:
        if record.price < bid:
            bid = record.price

    # Beat the current bid price
    print 'Current lowest bid price:' + " " + str(bid)
    bid *= settings['bid_factor']
    print 'Bidding:' + " " + str(bid)

    # Bid only if adjusted bid price is lower than on-demand instance price
    if bid < base_price:

        # Expire bid after a given amount of time
        incremented_time = datetime.utcnow() + timedelta(hours=settings['expiration_delta'])
        bid_expiration = incremented_time.strftime("%Y-%m-%dT%H:%M:%S")

        # Request spot instance #valid_until=None
        conn.request_spot_instances(price=bid,
                                    instance_type=instance_size,
                                    count=num_of_instances,
                                    image_id=ami,
                                    valid_until=bid_expiration,
                                    security_groups=security_groups)

        # Wait for 30 seconds for bid(s) to propagate
        sleep(30)

        requests = conn.get_all_spot_instance_requests()
        for request in requests:

            # Watch the status until the bid is fulfilled. Ignoring cancelled requests.
            status = conn.get_all_spot_instance_requests(request_ids=request.id)[0].state
            while status != 'active':
                sleep(10)
                status = conn.get_all_spot_instance_requests(request_ids=request.id)[0].state

            if status == 'active':
                # Once the request has been filled the instance ID will be available
                req = conn.get_all_spot_instance_requests(request_ids=request.id)[0]
                while not req.instance_id:
                    print 'Waiting to instance ID to populate'
                    sleep(45)

                # Get an instance object for the instance ID
                instance = conn.get_all_instances(instance_ids=req.instance_id)[0].instances[0]

                # Check up on its status every so often
                status = instance.update()
                while status == 'pending':
                    sleep(10)
                    status = instance.update()

                # Set EBS delete_on_termination to true so EBS does not persist after instance is destroyed.
                instance.modify_attribute('blockDeviceMapping', {'/dev/sda': True})

                # Print status and start bootstrapping once status returns running
                if status == "running":
                    if name:
                        instance.add_tag('Name', name)  # If name is present and instance is running a tag can be added
                    addr = instance.private_ip_address
                    ip = instance.ip_address
                    print('Hostname: ' + str(name))
                    print('Public IP Address: ' + ip)
                    print('Private IP Address: ' + addr)
                    print('Instance status: ' + str(status) + '\n')

                    bootstrap(name, environment, ip, addr)

     # If bid price is too high use on-demand instances instead
    else:
        provision(conn, ami, instance_size, security_groups, num_of_instances, environment, name)


if __name__ == "__main__":
    main(sys.argv[1:])
