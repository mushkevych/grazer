#!/usr/bin/python

__author__ = 'Nadir Merchant'

import sys

import boto.ec2.elb


def main(argv):

    instances = argv

    production_elb = 'narwhal'

    # Connect to AWS
    conn = boto.ec2.elb.connect_to_region('us-east-1',
                                          aws_access_key_id='AKIAJNK2P6DRSVAJI5UQ',
                                          aws_secret_access_key='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',)

    elb = conn.get_all_load_balancers(load_balancer_names=([production_elb]))[0]

    # Add agents back into load balancer
    for instance_id in instances:
        elb.register_instances(instance_id)


if __name__ == "__main__":
    main(sys.argv[1:])