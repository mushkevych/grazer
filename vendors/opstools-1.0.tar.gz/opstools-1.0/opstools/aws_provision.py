#!/usr/bin/python
__author__ = 'Nadir Merchant'

import sys
import time
import getopt
import textwrap

import boto.ec2
from boto.exception import EC2ResponseError

from settings import settings
from helpers.executor import bootstrap


def main(*argv):
    key = settings['AWS_KEY_ID']
    secret_key = settings['AWS_SECRET_KEY']
    region = settings['REGION']

    # Default values
    name = False
    environment = False
    persist_storage = False
    _bootstrap = False
    security_groups = settings['base_security_group']
    instance_size = settings['instance_size']
    num_of_instances = settings['num_of_instances']
    ami = settings['ami']
    seed = 1
    zone = None

    try:
        opts, args = getopt.getopt(argv[0], "bhs:g:e:n:x:a:v:z:")
    except getopt.GetoptError:
        print_help()
        sys.exit(2)

    # Connect to AWS
    conn = boto.ec2.connect_to_region(region,
                                      aws_access_key_id=key,
                                      aws_secret_access_key=secret_key)

    for opt, arg in opts:
        if opt == '-h':
            print_help()
            sys.exit()
        if opt == '-s':
            if validate_instance_size(arg):
                instance_size = arg
        if opt == '-g':
            groups = validate_group(conn, arg)
            security_groups.extend(groups)
        if opt == '-e':
            environment = validate_environment(arg)
        if opt == '-n':
            name = arg
        if opt == '-x':
            num_of_instances = int(arg)
        if opt == '-a':
            if validate_ami(conn, arg):
                ami = arg
        if opt == '-p':
            persist_storage = True
        if opt == '-v':
            seed = int(arg)
        if opt == '-z':
            zone = arg
        if opt == '-b':
            _bootstrap = True

    provision(conn, instance_size, security_groups, num_of_instances, environment, name, persist_storage, _bootstrap,
              zone, ami, seed)


def provision(conn, instance_size, security_groups, num_of_instances, environment, name, persist_storage, _bootstrap,
              zone=None, ami=settings['default_ami'],  seed=1):

    original_name = name

    print('Provisioning Instance...')

    reservation = conn.run_instances(
        ami,
        key_name='bluewhale',
        instance_type=instance_size,
        security_groups=security_groups,
        min_count=num_of_instances,
        max_count=num_of_instances,
        placement=zone)

    # Bootstrap instance(s) and print results
    for instance in xrange(0, num_of_instances):

        # After the first iteration increment hostname
        if name:
            name = increment_hostname(original_name, (instance + seed))

        # Get a reference to the next instance
        instance = reservation.instances[instance]

        # Check up on its status every so often
        status = instance.update()
        while status == 'pending':
            count = 0
            time.sleep(10)  # seconds
            status = instance.update()
            count += 1
            if count > 18:  # Wait for 3 minutes before giving up on the instance. TODO instance should be killed here
                break

        # Set EBS delete_on_termination to true so EBS does not persist after instance is destroyed.
        if not persist_storage:
            for num in range(0, 5):
                try:
                    instance.modify_attribute('blockDeviceMapping', {'/dev/sda': True})
                    break
                except:
                    time.sleep(10)  # 10 Seconds

        # Print status and start bootstrapping once status returns running
        if status == "running":
            if name:
                instance.add_tag('Name', name)  # If name is present and instance is running a tag can be added
            addr = instance.private_ip_address
            ip = instance.ip_address
            print('Hostname: %s' % str(name))
            print('Public IP Address: %s' % ip)
            print('Private IP Address: %s' % addr)
            print('Instance status: %s' % status + '\n')

            # TODO: Kill and re-provision if instances is not up after 5mins
            # If name and environment aren't present skip bootstrapping
            if name and environment and _bootstrap:
                bootstrap(name, environment, ip, addr)

    return reservation


def print_help():
    print textwrap.dedent("""
        Provisions and bootstraps a given number of EC2 instances in the N.Virginia region.
        If node name (-n) and environment (-e) are not provided instances will be provisioned but not bootstrapped.

        USAGE:
        -e:  Sets the puppet environment. Valid options: production, qa, infrastructure ci or staging.
        -n:  Sets the hostname of the instance. This is also the name that will appear in AWS name field.
             If provisioning multiple instances name will increment by one per node.

        -a:  Default: Infra-AMI :: Provide an AMI ID owned by Mobidia to provision.  Example ID:  ami-68af4100
        -s:  Default: m1.small  :: Sets instance size. If specified size is invalid default will be used.
        -g:  Default: Bluewhale :: Add additional security groups separated by comma. If group does not exist it will be created.
        -x:  Default: 1         :: Sets the number of instances to provision.
        -p:  Default: False     :: If set EBS volume will persists on termination of the EC2 instance.
        -v:  Default: 1         :: Sets the seed number for the hostname incrementation
        -z:  Default: Random    :: Sets the availability zone to launch the instance(s)
        """)


# Create security group if it is not already present
def validate_group(conn, arg):
    groups = arg.split(',')
    for group in groups:
        try:
            conn.create_security_group(group, group)
            print 'Created group: %s' % group
        except EC2ResponseError:
            pass
    return groups


# Ensure provided environment is a valid Puppet environment
def validate_environment(arg):
    environments = ['production', 'qa', 'infrastructure', 'ci', 'staging']
    if arg in environments:
        return arg
    else:
        print(arg + 'is not a valid environment')
        sys.exit()


# Ensure provided size is valid
def validate_instance_size(instance):
    """ Ensure provided EC2 type (size) is valid """
    sizes = ['m3.large', 'm3.xlarge', 'm3.2xlarge', 'm1.small', 'm1.medium', 'm3.medium', 'm1.large', 'm1.xlarge', 'c3.large',
             'c3.xlarge', 'c3.2xlarge', 'c3.4xlarge', 'c3.8xlarge', 'c1.medium', 'c1.xlarge', 'm2.xlarge',
             'm2.2xlarge', 'm2.4xlarge', 'hi1.4xlarge', 'hs1.8xlarge', 't1.micro', 't2.small', 't2.micro']
    if instance in sizes:
        return True
    else:
        print instance + ' is not a valid instance size using m1.small'
        return False


def increment_hostname(name, value):
    try:
        return name % str(value)
    except TypeError:
        return name


def validate_ami(conn, arg):
    """ Returns true if provided AMI ID is available to the provided AWS connection."""
    try:
        conn.get_image(arg)
        return True
    except EC2ResponseError:
        print(arg + ' is not a valid AMI ID, using default image')
        return False


if __name__ == "__main__":
    main(sys.argv[1:])
