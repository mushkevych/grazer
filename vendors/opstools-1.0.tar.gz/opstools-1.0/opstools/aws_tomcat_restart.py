#!/usr/bin/python

__author__ = 'Nadir Merchant'

# Remove bw-agents from ELB, restart broadcaster, add bw-agents to ELB

import getopt
import time
import sys
from subprocess import call

import boto.ec2.elb

from opstools.settings import settings


def main(*argv):
    instance_id = False
    hostname = False

    # Validate arguments
    try:
        opts, args = getopt.getopt(argv[0], "n:")
    except getopt.GetoptError:
        sys.exit(2)

    for opt, arg in opts:
        if opt == '-n':
            hostname = arg

    key = settings['AWS_KEY_ID']
    secret_key = settings['AWS_SECRET_KEY']
    region = settings['REGION']

    SLEEP_TIME = 60 * 5  # Sleep for 5 minutes

    if hostname == 'bw-agent-1':
        instance_id = 'i-6c1e263c'
    elif hostname == 'bw-agent-2':
        instance_id = 'i-291b2379'
    elif hostname == 'bw-agent-3':
        instance_id = 'i-dee2458d'
    elif hostname == 'bw-agent-4':
        instance_id = 'i-dde2458e'
    elif hostname == 'bw-agent-5':
        instance_id = 'i-dce2458f'

    production_elb = 'mdm-ue1c'

    # Connect to AWS
    conn = boto.ec2.elb.connect_to_region(region,
                                          aws_access_key_id=key,
                                          aws_secret_access_key=secret_key)

    # Get a reference to the production ELB
    elb = conn.get_all_load_balancers(load_balancer_names=([production_elb]))

    lb = elb[0]

    if instance_id:
        lb.deregister_instances(instance_id)
        print('Removed %s from %s Load Balancer' % (hostname, production_elb))

        time.sleep(SLEEP_TIME)

        # Restart broadcaster
        print('Restarting Tomcat')
        call('service tomcat6 restart', shell=True)

        # Add agents back into load balancer
        lb.register_instances(instance_id)
        print('Added %s to %s Load Balancer' % (hostname, production_elb))
    else:
        print(str(hostname) + " Not found")

if __name__ == "__main__":
    main(sys.argv[1:])