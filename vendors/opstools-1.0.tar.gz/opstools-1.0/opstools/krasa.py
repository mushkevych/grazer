#!/usr/local/bin/python2.7

__author__ = 'Nadir Merchant'

# Systems Orchestration based on Puppet catalog resources

# Developed and tested on Python 2.7

# Dependencies
    # pip install pypuppetdb
    # pip install fabric

# TODO Move search catalog section to a function

import getopt
import sys
from requests.exceptions import HTTPError
import textwrap
from subprocess import call

from pypuppetdb import connect

from helpers.executor import agent_kick, run_arbitrary


def main(argv):

    # setup switches
    all_nodes = False
    kick = False
    execute = False
    resource = False
    watch = False
    single_host = False
    pull = False
    nodes = False
    interactive = False
    command = False
    hostname = []

    try:
        opts, args = getopt.getopt(argv, "pAhkwr:H:iEl")
    except getopt.GetoptError:
        print_help()
        sys.exit(2)

    for opt, arg in opts:
        if opt == '-h':
            print_help()
            sys.exit()
        if opt == '-r':
            resource = arg
        if opt == '-k':
            kick = True
        if opt == '-A':
            all_nodes = True
        if opt == '-E':
            execute = True
            command = arg
        if opt == '-w':
            watch = True  # TODO: Implement fabric watch function
        if opt == '-H':
            single_host = arg
        if opt == '-p':
            pull = True
        if opt == '-i':
            interactive = True

    db = connect()

    # If single host is false get a list of all nodes.  Else if all nodes if false set hostname to single host
    if not single_host:
        nodes = db.nodes()
    elif not all_nodes:
        hostname.append(single_host)

    # If -r is used and all_nodes and single_host are false get hostnames from catalog else use all nodes
    if not all_nodes and not single_host and resource:
        # Iterator over each nodes catalog
        for node in nodes:
            try:
                catalog = db.catalog(node)
                for res in catalog.get_resources():
                    if res in catalog.get_resources():  # Convert to uppercase normalize strings
                        if res.name.upper() == resource.upper():
                            hostname.append(res.node)
            except HTTPError:
                pass
    # If all_nodes is true set hostname list to all nodes
    elif all_nodes:
        for node in nodes:
            hostname.append(node)

    hostnames = set(hostname)  # Convert list to set to ensure there are no dups

    # Execute chosen commands
    if execute:
        run_arbitrary(hostnames, command)
    if pull:
        deploy_puppet()
    if kick:
        agent_kick(hostnames)
    else:
        print('Selected hosts:')
        for item in hostnames:
            print(item)

    # After processing other options run interactive session
    first_run = True
    while interactive:
        # Only show instructions the first time through the loop
        if first_run:
            print('\nWelcome to Krasa interactive terminal. Type commands to execute on the hosts listed above')
            print('Type CLOSE to exit\n')
            first_run = False

        command = raw_input('krasa$ ')
        if command == 'CLOSE':
            break
        run_arbitrary(hostnames, command)


def deploy_puppet():
    call('cd /home/puppet/puppet-skeleton && git pull origin master', shell=True)
    call('/home/puppet/puppet-skeleton/production_deploy.sh', shell=True)


def print_help():
        print textwrap.dedent("""\
        Fetches a list of hostnames from Puppetdb based on resource or class names and optionally executed commands on them.
        If no executable option is used matched hostnames will print.  Useful for testing before execution.
        Example: ./krasa -r profile::copperlight will print the hostnames of all hosts inheriting the copperlight profile.

        USAGE:

        Selecting host(s):
        -r:  Set a resource to match.  Can be resource title, or class name.  Ex: role::bw-agent or tomcat6.
             Use double quotes for resource with spaces or character which could be operators.  Ex: "/tmp/install_distribute.sh"
        -H:  Specify a singe host to run on
        -A:  Runs the provided command on all active Puppet agents.

        Selecting command(s) to execute:
        -p:  Pull and deploy latest Puppet code on Puppet-Master (krasa must be running on PM to use this)
        -k:  Runs "puppet apply -t" on match hosts.  This will trigger a one-time puppet run.
        -E:  Executes a provided command on the matched hosts.  Again use double quotes as needed.
        -w:  Watch logfile for Puppet run completion message.  Log will not be shown just run completion message.
             WARNING: Program will not exit until run is complete which can take a long time.
        -i:  Starts interactive session to execute multiple arbitrary commands on hosts.
        """)


def search_catalog(node):
    pass

if __name__ == "__main__":
    main(sys.argv[1:])