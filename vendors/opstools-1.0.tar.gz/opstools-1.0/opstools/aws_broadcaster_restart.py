#!/usr/bin/python

__author__ = 'Nadir Merchant'

# Remove bw-agents from ELB, restart broadcaster, add bw-agents to ELB

import time
import sys
from subprocess import call

import boto.ec2.elb

from opstools.settings import settings


def main(argv):

    key = settings['AWS_KEY_ID']
    secret_key = settings['AWS_SECRET_KEY']
    region = settings['REGION']

    SLEEP_TIME = 60 * 5  # Sleep for 5 minutes

    bw_agents = {'bw-agent-1': 'i-6c1e263c',
                 'bw-agent-2': 'i-291b2379',
                 'bw-agent-3': 'i-dee2458d',
                 'bw-agent-4': 'i-dde2458e',
                 'bw-agent-5': 'i-dce2458f'}

    production_elb = 'mdm-ue1c'

# Connect to AWS
    conn = boto.ec2.elb.connect_to_region(region,
                                            aws_access_key_id=key,
                                            aws_secret_access_key=secret_key)

    elb = conn.get_all_load_balancers(load_balancer_names=([production_elb]))
    lb = elb[0]

    # Remove agents from load balancer
    for agent, instance_id in bw_agents.iteritems():
            lb.deregister_instances(instance_id)
            print('Removed %s from %s Load Balancer' % (agent, production_elb))

    time.sleep(SLEEP_TIME)

    # Restart broadcaster
    print('Terminating broadcaster')
    call('/mnt/broadcaster/deployment/scripts/kill_all.sh', shell=True)

    print('Starting broadcaster')
    call('python2.7 /mnt/broadcaster/deployment/launch.py -r --app Broadcaster', shell=True)

    # Add agents back into load balancer
    for agent, instance_id in bw_agents.iteritems():
        lb.register_instances(instance_id)
        print('Added %s to %s Load Balancer' % (agent, production_elb))


if __name__ == "__main__":
    main(sys.argv[1:])